# QueueCare_Atayde
Midterm project — QueueCare, a SwiftUI virtual queue app (MVC) backed by Firebase.

## Firebase setup
1. Firebase console → create a project → add an **iOS app** with this app's bundle ID.
2. Download `GoogleService-Info.plist` and add it to the **Midterms** target in Xcode.
3. Xcode → File → Add Package Dependencies → `https://github.com/firebase/firebase-ios-sdk`
   → add **FirebaseAuth** and **FirebaseFirestore** to the Midterms target.
4. Console → Authentication → enable **Email/Password**.
5. Console → Firestore Database → create a database. For the first run use **test mode**
   (the Debug build uploads `QueueSeed.json` to Firestore once: `config/app` and `offices/*`).
6. After seeding, publish `firestore.rules` (Firestore → Rules) to lock the database down.

## Moving the line
Staff advance a queue by editing `currentlyServing` on the office document
(`offices/<office>`) in the Firebase console. Every student's screen updates live.

## Staff / admin
1. Sign up in the app with the staff member's account.
2. Firebase console → Firestore → `students` → that user's document → **Add field**
   `isStaff` (boolean) = `true`. Sign out and back in.
3. A **Staff** tab appears: pick an office, then **Complete & Call Next** or **No-show & Call Next**.
4. Publish the updated `firestore.rules` so only staff can move a queue.
