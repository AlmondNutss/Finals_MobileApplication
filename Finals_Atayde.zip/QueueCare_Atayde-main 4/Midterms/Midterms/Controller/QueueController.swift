//
//  QueueController.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import Foundation
import Combine

final class QueueController: ObservableObject {

    // MARK: Published state — drives the Views

    // Session
    @Published var isLoggedIn: Bool = false
    @Published var isRestoring: Bool = true
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var studentName: String = ""
    @Published var studentID: String = ""

    // Live data from the backend
    @Published var offices: [Office] = []
    @Published var appSubtitle: String = ""
    @Published private var tickets: [Ticket] = []

    // What the student is currently browsing in Join Queue
    @Published var currentOffice: Office?
    @Published var selectedTransaction: TransactionType?

    // Live countdown (seconds) to the estimated turn
    @Published var remainingSeconds: Int = 0

    // Staff mode (students/{uid}.isStaff == true)
    @Published var isStaff: Bool = false
    @Published var staffOfficeID: String?
    @Published private var staffTickets: [Ticket] = []

    // MARK: Derived queue state (computed from live tickets + offices)

    private var activeTicket: Ticket? {
        tickets.first { $0.status == .active }
    }

    var hasActiveQueue: Bool {
        activeTicket != nil
    }

    var activeOffice: Office? {
        guard let ticket = activeTicket else { return nil }
        return offices.first { $0.id == ticket.officeID }
    }

    var activeTransactionName: String? {
        activeTicket?.transactionName
    }

    var queueNumber: String {
        activeTicket?.queueNumber ?? ""
    }

    var queueState: QueueState {
        guard let ticket = activeTicket else { return .none }
        guard let office = activeOffice else { return .waiting }
        return office.currentlyServing >= ticket.number ? .yourTurn : .waiting
    }

    var peopleAhead: Int {
        guard let ticket = activeTicket, let office = activeOffice else { return 0 }
        return max(ticket.number - office.currentlyServing - 1, 0)
    }

    var nowServing: String {
        guard let ticket = activeTicket, let office = activeOffice else { return "" }
        if queueState == .yourTurn { return ticket.queueNumber }
        return formattedNumber(office.currentlyServing, prefix: office.queuePrefix)
    }

    var estimatedWaitMinutes: Int {
        Int((Double(remainingSeconds) / 60).rounded(.up))
    }

    /// Live countdown
    var countdownText: String {
        String(format: "%d:%02d", remainingSeconds / 60, remainingSeconds % 60)
    }

    /// Past tickets, newest first.
    var history: [HistoryEntry] {
        tickets
            .sorted { $0.createdAt > $1.createdAt }
            .compactMap { ticket -> HistoryEntry? in
                guard let status = ticket.status.historyStatus else { return nil }
                return HistoryEntry(
                    id: ticket.id,
                    queueNumber: ticket.queueNumber,
                    office: ticket.officeName,
                    transaction: ticket.transactionName,
                    date: Self.dateFormatter.string(from: ticket.createdAt),
                    status: status
                )
            }
    }

    // MARK: Private state

    private let service: any QueueService
    private var student: StudentProfile?
    private var minutesPerPerson: Double = 0

    private var officesListener: QueueListener?
    private var ticketsListener: QueueListener?
    private var staffListener: QueueListener?

    private var timerCancellable: AnyCancellable?
    private var turnDate: Date?
    private var countdownKey: String?

    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy"
        return formatter
    }()

    // MARK: - Init

    init(service: any QueueService = FirebaseQueueService()) {
        self.service = service
    }

    // MARK: - Session

    /// Restores an existing Firebase session on launch.
    func start() async {
        defer { isRestoring = false }
        guard service.currentUserID != nil else { return }
        do {
            try await loadSession()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func signIn(email: String, password: String) async {
        await authenticate {
            try await self.service.signIn(email: email, password: password)
        }
    }

    func register(email: String, password: String, name: String, studentID: String) async {
        await authenticate {
            try await self.service.register(
                email: email,
                password: password,
                name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                studentID: studentID.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        }
    }

    private func authenticate(_ action: () async throws -> Void) async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        do {
            try await action()
            try await loadSession()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func loadSession() async throws {
        #if DEBUG
        try await service.seedIfNeeded()
        #endif
        let config = try await service.fetchConfig()
        let profile = try await service.fetchProfile()

        appSubtitle = config.appSubtitle
        minutesPerPerson = config.averageMinutesPerPerson
        student = profile
        studentName = profile.name
        studentID = profile.studentID
        isStaff = profile.isStaff

        startListening()
        isLoggedIn = true
    }

    /// Ends the session. An active ticket stays in the queue and reappears on the next sign-in.
    func logout() {
        Task {
            stopListening()
            do {
                try service.signOut()
            } catch {
                errorMessage = error.localizedDescription
            }

            tickets = []
            offices = []
            student = nil
            currentOffice = nil
            selectedTransaction = nil
            studentName = ""
            studentID = ""
            isStaff = false
            staffOfficeID = nil
            staffTickets = []
            syncCountdown()
            isLoggedIn = false
        }
    }

    // MARK: - Reference data helpers

    func transactions(for office: Office) -> [TransactionType] {
        office.transactions
    }

    /// Estimated wait (in minutes) for someone joining `office` right now.
    func estimatedWait(for office: Office) -> Int {
        Int((Double(office.peopleWaiting) * minutesPerPerson).rounded(.up))
    }

    // MARK: - Intents

    func selectOffice(_ office: Office) {
        currentOffice = office
        selectedTransaction = nil
    }

    func selectTransaction(_ transaction: TransactionType) {
        selectedTransaction = transaction
    }

    /// Takes the next ticket for the selected office/transaction.
    func joinQueue() async {
        guard !isLoading, !hasActiveQueue,
              let office = currentOffice,
              let transaction = selectedTransaction,
              let student else { return }

        isLoading = true
        errorMessage = nil
        do {
            try await service.joinQueue(office: office, transaction: transaction, student: student)
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    /// Cancels the active queue (it moves to history as Cancelled).
    func leaveQueue() {
        guard let ticket = activeTicket else { return }
        update(ticket, to: .cancelled)
    }

    /// Called when the student has been served after their turn.
    func completeQueue() {
        guard let ticket = activeTicket, queueState == .yourTurn else { return }
        update(ticket, to: .completed)
    }

    /// Returns history entries matching `status`, or everything when `status` is nil.
    func filterHistory(by status: HistoryStatus?) -> [HistoryEntry] {
        guard let status else { return history }
        return history.filter { $0.status == status }
    }

    private func update(_ ticket: Ticket, to status: TicketStatus) {
        Task {
            do {
                try await service.updateTicket(id: ticket.id, status: status)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    // MARK: - Staff

    var staffOffice: Office? {
        offices.first { $0.id == staffOfficeID }
    }

    /// The ticket currently being served at the selected office.
    var staffServingTicket: Ticket? {
        guard let office = staffOffice else { return nil }
        return staffTickets.first { $0.number <= office.currentlyServing }
    }

    /// Tickets not called yet, in order.
    var staffWaitingTickets: [Ticket] {
        guard let office = staffOffice else { return [] }
        return staffTickets.filter { $0.number > office.currentlyServing }
    }

    func selectStaffOffice(_ officeID: String) {
        staffOfficeID = officeID
        staffTickets = []
        staffListener?.remove()
        staffListener = service.listenToOfficeTickets(officeID: officeID) { [weak self] tickets in
            self?.staffTickets = tickets
        }
    }

    private func selectDefaultStaffOfficeIfNeeded() {
        guard isStaff, staffOfficeID == nil, let first = offices.first else { return }
        selectStaffOffice(first.id)
    }

    /// Finishes the person being served (completed or no-show) and calls the next one.
    func advanceQueue(servedStatus: TicketStatus) async {
        guard isStaff, !isLoading, let office = staffOffice else { return }
        isLoading = true
        errorMessage = nil
        do {
            try await service.advanceQueue(office: office, servedStatus: servedStatus)
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    // MARK: - Live listeners

    private func startListening() {
        stopListening()

        officesListener = service.listenToOffices { [weak self] offices in
            self?.offices = offices
            self?.selectDefaultStaffOfficeIfNeeded()
            self?.syncCountdown()
        }

        ticketsListener = service.listenToTickets { [weak self] tickets in
            self?.tickets = tickets
            self?.syncCountdown()
        }
    }

    private func stopListening() {
        officesListener?.remove()
        ticketsListener?.remove()
        staffListener?.remove()
        officesListener = nil
        ticketsListener = nil
        staffListener = nil
    }

    // MARK: - Real-time countdown

    /// Re-aims the countdown whenever the line moves (people ahead changes) or
    /// the active ticket changes; in between, a 1-second timer counts it down.
    private func syncCountdown() {
        let key: String? = {
            guard let ticket = activeTicket, queueState == .waiting else { return nil }
            return "\(ticket.id)-\(peopleAhead)"
        }()

        guard key != countdownKey else { return }
        countdownKey = key

        if key != nil {
            turnDate = Date().addingTimeInterval(Double(peopleAhead) * minutesPerPerson * 60)
            updateRemaining()
            if remainingSeconds > 0 {
                startTimer()
            } else {
                stopTimer()
            }
        } else {
            turnDate = nil
            remainingSeconds = 0
            stopTimer()
        }
    }

    private func updateRemaining() {
        guard let turnDate else {
            remainingSeconds = 0
            return
        }
        remainingSeconds = max(0, Int(turnDate.timeIntervalSinceNow.rounded(.up)))
        if remainingSeconds == 0 {
            stopTimer()
        }
    }

    private func startTimer() {
        stopTimer()
        timerCancellable = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                self?.updateRemaining()
            }
    }

    private func stopTimer() {
        timerCancellable?.cancel()
        timerCancellable = nil
    }

    // MARK: - Helpers

    private func formattedNumber(_ number: Int, prefix: String) -> String {
        "\(prefix)-" + String(format: "%03d", number)
    }
}
