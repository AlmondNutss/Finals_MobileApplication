//
//  ErrorBannerView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct ErrorBannerView: View {
    let message: String
    var onDismiss: () -> Void = { }

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
            Text(message)
                .font(.caption)
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)
            Button(action: onDismiss) {
                Image(systemName: "xmark")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .background(Color.red.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    ErrorBannerView(message: "Something went wrong.")
        .padding()
}
