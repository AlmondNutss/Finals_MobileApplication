//
//  HistoryRowView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//


import SwiftUI

struct HistoryRow: View {
    let entry: HistoryEntry

    var body: some View {
        HStack {
            Text(entry.queueNumber)
                .font(.caption.bold())
                .frame(width: 50, height: 44)
                .background(Color.red.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 2) {
                Text(entry.office)
                    .font(.subheadline.weight(.semibold))
                Text(entry.transaction)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(entry.date)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(entry.status.rawValue)
                .font(.caption2.bold())
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(statusColor.opacity(0.15))
                .foregroundStyle(statusColor)
                .clipShape(Capsule())
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var statusColor: Color {
        switch entry.status {
        case .completed: return .green
        case .cancelled: return .red
        case .noShow: return .orange
        }
    }
}

#Preview {
    HistoryRow(entry: HistoryEntry(
        queueNumber: "R-019",
        office: "Registrar",
        transaction: "Transcript Request",
        date: "Sept 2, 2026",
        status: .completed
    ))
    .padding()
}
