//
//  StatBox.swift
//  Midterms
//
//  Created by Mac-LAB on 9/8/26.
//


import SwiftUI

struct StatBox: View {
    let value: String
    let label: String

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.title3.bold())
                .foregroundStyle(.blue)
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    HStack {
        StatBox(value: "12", label: "People waiting")
        StatBox(value: "~18 min", label: "Est. wait time")
    }
    .padding()
}
