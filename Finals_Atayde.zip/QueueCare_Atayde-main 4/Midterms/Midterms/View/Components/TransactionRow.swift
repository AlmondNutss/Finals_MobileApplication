//
//  TransactionRow.swift
//  Midterms
//
//  Created by Mac-LAB on 9/8/26.
//


import SwiftUI

struct TransactionRow: View {
    let transaction: TransactionType
    let isSelected: Bool

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(transaction.name)
                    .font(.subheadline.weight(.semibold))
                Text(transaction.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: isSelected ? "largecircle.fill.circle" : "circle")
                .foregroundStyle(isSelected ? .blue : .secondary)
        }
        .padding()
        .background(isSelected ? Color.blue.opacity(0.08) : Color(.secondarySystemBackground))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 1.5)
        )
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    TransactionRow(
        transaction: TransactionType(name: "Transcript Request", description: "Official Transcript of Records"),
        isSelected: true
    )
    .padding()
}
