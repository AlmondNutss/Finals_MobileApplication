//
//  ActiveQueueCardView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct ActiveQueueCardView: View {
    let officeName: String
    let queueNumber: String
    let peopleAhead: Int
    let estimatedWait: Int
    var state: QueueState = .waiting

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("ACTIVE QUEUE")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.8))
                    Text(officeName)
                        .font(.headline)
                        .foregroundStyle(.white)
                }
                Spacer()
                Text(state.rawValue)
                    .font(.caption2.weight(.bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(.white.opacity(0.2))
                    .clipShape(Capsule())
                    .foregroundStyle(.white)
            }

            Text(queueNumber)
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .foregroundStyle(.white)

            HStack(spacing: 24) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("\(peopleAhead)")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("People ahead")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.8))
                }
                VStack(alignment: .leading, spacing: 1) {
                    Text("\(estimatedWait) min")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("Est. wait")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.8))
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(colors: [.red, .black], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

#Preview {
    ActiveQueueCardView(officeName: "Registrar", queueNumber: "R-024", peopleAhead: 3, estimatedWait: 15)
        .padding()
}
