//
//  ServiceCardView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct ServiceCardView: View {
    let office: Office

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: office.iconName)
                .font(.title2)
                .foregroundStyle(.blue)
                .frame(width: 40, height: 40)
                .background(Color.blue.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 10))

            Text(office.name)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)

            Text("\(office.peopleWaiting) waiting")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    ServiceCardView(office: Office(name: "Registrar", iconName: "doc.text.fill", peopleWaiting: 12))
        .padding()
}
