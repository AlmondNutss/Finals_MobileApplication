//
//  QueueCareLogoView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct QueueCareLogoView: View {
    var showsWordmark: Bool = true
    var subtitle: String = ""

    var body: some View {
        HStack(spacing: 10) {
            RoundedRectangle(cornerRadius: 11)
                .fill(
                    LinearGradient(colors: [.red, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                .frame(width: 38, height: 38)
                .overlay(
                    Image(systemName: "list.bullet.rectangle.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white)
                )

            if showsWordmark {
                VStack(alignment: .leading, spacing: 0) {
                    Text("QueueCare")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    if !subtitle.isEmpty {
                        Text(subtitle)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

#Preview {
    QueueCareLogoView()
        .padding()
}
