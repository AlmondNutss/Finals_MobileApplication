//
//  MainTabView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct MainTabView: View {
    @StateObject private var controller = QueueController()

    var body: some View {
        Group {
            if controller.isRestoring {
                ProgressView()
            } else if controller.isLoggedIn {
                TabView {
                    NavigationStack {
                        HomeView()
                    }
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }

                    NavigationStack {
                        QueueStatusView()
                    }
                    .tabItem {
                        Label("Queue", systemImage: "clock.fill")
                    }

                    NavigationStack {
                        QueueHistoryView()
                    }
                    .tabItem {
                        Label("History", systemImage: "clock.arrow.circlepath")
                    }

                    if controller.isStaff {
                        NavigationStack {
                            StaffView()
                        }
                        .tabItem {
                            Label("Staff", systemImage: "person.badge.key.fill")
                        }
                    }
                }
            } else {
                LoginView()
            }
        }
        .environmentObject(controller)
        .tint(.blue)
        .task {
            await controller.start()
        }
    }
}

#Preview {
    MainTabView()
}
