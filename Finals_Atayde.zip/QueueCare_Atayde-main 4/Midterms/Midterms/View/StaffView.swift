//
//  StaffView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct StaffView: View {
    @EnvironmentObject var controller: QueueController

    private var officeSelection: Binding<String> {
        Binding(
            get: { controller.staffOfficeID ?? "" },
            set: { controller.selectStaffOffice($0) }
        )
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let message = controller.errorMessage {
                    ErrorBannerView(message: message) {
                        controller.errorMessage = nil
                    }
                }

                HStack {
                    Text("Office")
                        .font(.headline)
                    Spacer()
                    Picker("Office", selection: officeSelection) {
                        ForEach(controller.offices) { office in
                            Text(office.name).tag(office.id)
                        }
                    }
                    .pickerStyle(.menu)
                }

                if let office = controller.staffOffice {
                    servingCard(for: office)
                    actionButtons
                    waitingList
                } else {
                    Text("No services available yet.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
        }
        .navigationTitle("Staff")
    }

    private func servingCard(for office: Office) -> some View {
        VStack(spacing: 6) {
            Text("NOW SERVING")
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)

            Text(controller.staffServingTicket?.queueNumber ?? "—")
                .font(.system(size: 48, weight: .heavy, design: .rounded))
                .foregroundStyle(.blue)

            if let ticket = controller.staffServingTicket {
                Text("\(ticket.studentName) • \(ticket.transactionName)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else {
                Text("No one is being served")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Text("\(controller.staffWaitingTickets.count) waiting • \(office.windowLabel)")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.blue.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var actionButtons: some View {
        let hasServing = controller.staffServingTicket != nil
        let hasWaiting = !controller.staffWaitingTickets.isEmpty

        return VStack(spacing: 10) {
            Button {
                Task { await controller.advanceQueue(servedStatus: .completed) }
            } label: {
                Text(hasServing ? "Complete & Call Next" : "Call Next")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background((hasServing || hasWaiting) ? Color.blue : Color.blue.opacity(0.4))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .disabled(controller.isLoading || !(hasServing || hasWaiting))

            if hasServing {
                Button {
                    Task { await controller.advanceQueue(servedStatus: .noShow) }
                } label: {
                    Text("No-show & Call Next")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .foregroundStyle(.red)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .disabled(controller.isLoading)
            }
        }
    }

    private var waitingList: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Waiting")
                .font(.headline)

            if controller.staffWaitingTickets.isEmpty {
                Text("Nobody is waiting.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(controller.staffWaitingTickets) { ticket in
                    HStack {
                        Text(ticket.queueNumber)
                            .font(.subheadline.weight(.bold))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(ticket.studentName)
                                .font(.subheadline)
                            Text(ticket.transactionName)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            }
        }
    }
}

#Preview {
    NavigationStack {
        StaffView()
    }
    .environmentObject(QueueController())
}
