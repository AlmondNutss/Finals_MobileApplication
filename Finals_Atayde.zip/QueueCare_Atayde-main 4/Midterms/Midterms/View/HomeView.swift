//
//  HomeView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var controller: QueueController
    @State private var showLogout = false

    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header
                greeting

                if let message = controller.errorMessage {
                    ErrorBannerView(message: message) {
                        controller.errorMessage = nil
                    }
                }

                if controller.hasActiveQueue {
                    VStack(spacing: 10) {
                        ActiveQueueCardView(
                            officeName: controller.activeOffice?.name ?? "",
                            queueNumber: controller.queueNumber,
                            peopleAhead: controller.peopleAhead,
                            estimatedWait: controller.estimatedWaitMinutes,
                            state: controller.queueState
                        )

                        NavigationLink {
                            QueueStatusView()
                        } label: {
                            Text("View Queue")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                } else {
                    EmptyQueueView()
                }

                Text("Available Services")
                    .font(.headline)

                if controller.offices.isEmpty {
                    Text("No services available yet.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(controller.offices) { office in
                        NavigationLink(value: office) {
                            ServiceCardView(office: office)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("QueueCare")
        .navigationDestination(for: Office.self) { office in
            JoinQueueView(office: office)
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showLogout = true
                } label: {
                    Image(systemName: "person.crop.circle")
                }
            }
        }
        .sheet(isPresented: $showLogout) {
            LogoutView()
        }
    }

    private var header: some View {
        HStack {
            QueueCareLogoView(subtitle: controller.appSubtitle)
            Spacer()
        }
    }

    private var greetingText: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good morning,"
        case 12..<18: return "Good afternoon,"
        default: return "Good evening,"
        }
    }

    private var greeting: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(greetingText)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(controller.studentName.isEmpty ? "Student" : controller.studentName)
                .font(.title3.bold())
        }
    }
}

#Preview {
    NavigationStack {
        HomeView()
    }
    .environmentObject(QueueController())
}
