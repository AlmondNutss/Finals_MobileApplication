//
//  QueuehistoryView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct QueueHistoryView: View {
    @EnvironmentObject var controller: QueueController

    @State private var selectedFilter: HistoryStatus?

    private var entries: [HistoryEntry] {
        controller.filterHistory(by: selectedFilter)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                filterRow

                if entries.isEmpty {
                    Text("No transactions to show.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.top, 40)
                } else {
                    ForEach(entries) { entry in
                        HistoryRow(entry: entry)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Queue History")
    }

    private var filterRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                filterChip(title: "All", status: nil)
                filterChip(title: "Completed", status: .completed)
                filterChip(title: "Cancelled", status: .cancelled)
                filterChip(title: "No-show", status: .noShow)
            }
        }
    }

    private func filterChip(title: String, status: HistoryStatus?) -> some View {
        Text(title)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(selectedFilter == status ? Color.blue : Color(.secondarySystemBackground))
            .foregroundStyle(selectedFilter == status ? .white : .primary)
            .clipShape(Capsule())
            .onTapGesture {
                selectedFilter = status
            }
    }
}

#Preview {
    NavigationStack {
        QueueHistoryView()
    }
    .environmentObject(QueueController())
}
