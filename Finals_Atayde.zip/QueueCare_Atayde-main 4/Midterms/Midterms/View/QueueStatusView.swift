//
//  QueueStatusView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct QueueStatusView: View {
    @EnvironmentObject var controller: QueueController
    @State private var confirmLeave = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if let message = controller.errorMessage {
                    ErrorBannerView(message: message) {
                        controller.errorMessage = nil
                    }
                }

                if controller.hasActiveQueue {
                    statusBadge

                    Text(controller.queueNumber)
                        .font(.system(size: 56, weight: .heavy, design: .rounded))
                        .foregroundStyle(.blue)

                    if let office = controller.activeOffice,
                       let transactionName = controller.activeTransactionName {
                        Text("\(office.name) • \(transactionName)")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }

                    Text("Now Serving \(controller.nowServing)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    Divider()

                    HStack(spacing: 40) {
                        metaItem(value: "\(controller.peopleAhead)", label: "People ahead")
                        metaItem(value: controller.countdownText, label: "Est. wait (min:sec)")
                    }

                    if controller.queueState == .yourTurn {
                        yourTurnCallout

                        Button {
                            controller.completeQueue()
                        } label: {
                            Text("Done — Transaction Completed")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }

                    Button(role: .destructive) {
                        confirmLeave = true
                    } label: {
                        Text("Leave Queue")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                    }
                    .background(Color.red.opacity(0.1))
                    .foregroundStyle(.red)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                } else {
                    EmptyQueueView(message: "Go to Home and pick a service to join a queue.")
                }
            }
            .padding()
        }
        .navigationTitle("Queue Status")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Leave this queue?", isPresented: $confirmLeave, titleVisibility: .visible) {
            Button("Leave Queue", role: .destructive) {
                controller.leaveQueue()
            }
            Button("Stay in Queue", role: .cancel) { }
        } message: {
            Text("You'll lose your spot (\(controller.queueNumber)).")
        }
    }

    private var windowText: String {
        controller.activeOffice?.windowLabel ?? "the service window"
    }

    private var statusBadge: some View {
        Text(controller.queueState.rawValue)
            .font(.caption.weight(.bold))
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(controller.queueState == .yourTurn ? Color.green.opacity(0.15) : Color.orange.opacity(0.15))
            .foregroundStyle(controller.queueState == .yourTurn ? .green : .orange)
            .clipShape(Capsule())
    }

    private var yourTurnCallout: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.green)
            VStack(alignment: .leading, spacing: 2) {
                Text("It's your turn!")
                    .font(.subheadline.weight(.bold))
                Text("Please proceed to \(windowText).")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding()
        .background(Color.green.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func metaItem(value: String, label: String) -> some View {
        VStack {
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}

#Preview {
    NavigationStack {
        QueueStatusView()
    }
    .environmentObject(QueueController())
}
