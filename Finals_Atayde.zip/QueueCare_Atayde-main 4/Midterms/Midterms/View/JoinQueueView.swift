//
//  JoinQueueView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct JoinQueueView: View {
    @EnvironmentObject var controller: QueueController
    let office: Office

    @State private var navigateToStatus = false

    /// The office with its latest live numbers (the `office` value is a snapshot).
    private var liveOffice: Office {
        controller.offices.first { $0.id == office.id } ?? office
    }

    private var canJoin: Bool {
        controller.selectedTransaction != nil && !controller.hasActiveQueue
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                officeBanner

                if let message = controller.errorMessage {
                    ErrorBannerView(message: message) {
                        controller.errorMessage = nil
                    }
                }

                if controller.hasActiveQueue {
                    activeQueueNotice
                }

                Text("Choose Transaction")
                    .font(.headline)

                ForEach(controller.transactions(for: office)) { transaction in
                    TransactionRow(
                        transaction: transaction,
                        isSelected: controller.selectedTransaction == transaction
                    )
                    .onTapGesture {
                        controller.selectTransaction(transaction)
                    }
                }

                HStack(spacing: 12) {
                    StatBox(value: "\(liveOffice.peopleWaiting)", label: "People waiting")
                    StatBox(value: "~\(controller.estimatedWait(for: liveOffice)) min", label: "Est. wait time")
                }
                .padding(.top, 8)
            }
            .padding()
        }
        .navigationTitle(office.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            controller.selectOffice(office)
        }
        .safeAreaInset(edge: .bottom) {
            Button {
                Task {
                    await controller.joinQueue()
                    if controller.hasActiveQueue {
                        navigateToStatus = true
                    }
                }
            } label: {
                Text(controller.hasActiveQueue ? "Already in a Queue" : "Join Queue")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(canJoin ? Color.blue : Color.blue.opacity(0.4))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .disabled(!canJoin || controller.isLoading)
            .padding()
            .background(.ultraThinMaterial)
        }
        .navigationDestination(isPresented: $navigateToStatus) {
            QueueStatusView()
        }
    }

    private var activeQueueNotice: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "info.circle.fill")
                .foregroundStyle(.orange)
            Text("You already have an active queue. Leave it first to join another office.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.orange.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var officeBanner: some View {
        HStack {
            Image(systemName: office.iconName)
                .font(.title2)
                .foregroundStyle(.blue)
                .frame(width: 44, height: 44)
                .background(Color.blue.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 2) {
                Text(office.name)
                    .font(.headline)
                Text(office.location)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding()
        .background(Color.blue.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    NavigationStack {
        JoinQueueView(office: Office(name: "Registrar", iconName: "doc.text.fill", peopleWaiting: 12))
    }
    .environmentObject(QueueController())
}
