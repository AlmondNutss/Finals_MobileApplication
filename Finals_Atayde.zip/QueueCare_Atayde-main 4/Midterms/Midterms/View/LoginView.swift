//
//  LoginView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct LoginView: View {
    @EnvironmentObject var controller: QueueController

    @State private var isRegistering = false
    @State private var name = ""
    @State private var studentID = ""
    @State private var email = ""
    @State private var password = ""

    private func isBlank(_ text: String) -> Bool {
        text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private var canSubmit: Bool {
        guard email.contains("@"), password.count >= 6 else { return false }
        if isRegistering {
            return !isBlank(name) && !isBlank(studentID)
        }
        return true
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer(minLength: 40)

                QueueCareLogoView(subtitle: controller.appSubtitle)

                VStack(spacing: 6) {
                    Text(isRegistering ? "Create your account" : "Welcome to QueueCare")
                        .font(.title2.bold())
                    Text("Join a queue without the wait in line.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                if let message = controller.errorMessage {
                    ErrorBannerView(message: message) {
                        controller.errorMessage = nil
                    }
                }

                VStack(spacing: 12) {
                    if isRegistering {
                        field("Full name", text: $name)
                            .textContentType(.name)
                        field("Student ID", text: $studentID)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }

                    field("Email", text: $email)
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("Password (6+ characters)", text: $password)
                        .textContentType(isRegistering ? .newPassword : .password)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }

                Button {
                    controller.errorMessage = nil
                    Task {
                        if isRegistering {
                            await controller.register(email: email, password: password, name: name, studentID: studentID)
                        } else {
                            await controller.signIn(email: email, password: password)
                        }
                    }
                } label: {
                    Group {
                        if controller.isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Text(isRegistering ? "Create Account" : "Sign In")
                                .font(.headline)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(canSubmit ? Color.blue : Color.blue.opacity(0.4))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .disabled(!canSubmit || controller.isLoading)

                Button {
                    isRegistering.toggle()
                    controller.errorMessage = nil
                } label: {
                    Text(isRegistering ? "Already have an account? Sign in" : "New here? Create an account")
                        .font(.footnote)
                }

                Spacer(minLength: 40)
            }
            .padding()
        }
        .background(Color(.systemBackground))
    }

    private func field(_ title: String, text: Binding<String>) -> some View {
        TextField(title, text: text)
            .padding()
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    LoginView()
        .environmentObject(QueueController())
}
