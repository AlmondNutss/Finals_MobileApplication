//
//  LogoutView.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI

struct LogoutView: View {
    @EnvironmentObject var controller: QueueController
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 24) {
            Capsule()
                .fill(Color(.tertiaryLabel))
                .frame(width: 40, height: 5)
                .padding(.top, 8)

            Spacer()

            QueueCareLogoView(showsWordmark: false)

            VStack(spacing: 6) {
                Text("Log out of QueueCare?")
                    .font(.title3.bold())
                Text("You'll need to sign in again with your student account to rejoin any queue.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)

                if controller.hasActiveQueue {
                    Text("Your active queue (\(controller.queueNumber)) stays in the line. Sign back in to see it.")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            VStack(spacing: 10) {
                Button(role: .destructive) {
                    controller.logout()
                    dismiss()
                } label: {
                    Text("Logout")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }

                Button("Cancel") {
                    dismiss()
                }
                .font(.subheadline.weight(.semibold))
                .padding(.vertical, 6)
            }
        }
        .padding()
    }
}

#Preview {
    LogoutView()
        .environmentObject(QueueController())
}
