//
//  QueueModels.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import Foundation

// MARK: - Transaction

nonisolated struct TransactionType: Identifiable, Hashable {
    let name: String
    let description: String

    var id: String { name }
}

// MARK: - Office

nonisolated struct Office: Identifiable, Hashable {
    /// Firestore document ID.
    let id: String
    let name: String
    let iconName: String
    /// People who have a ticket but have not been called yet (live).
    let peopleWaiting: Int
    let queuePrefix: String
    let location: String
    let windowLabel: String
    /// Ticket number currently being served (live).
    let currentlyServing: Int
    let transactions: [TransactionType]

    init(
        name: String,
        iconName: String,
        peopleWaiting: Int,
        queuePrefix: String = "Q",
        location: String = "",
        windowLabel: String = "Service Window",
        currentlyServing: Int = 0,
        transactions: [TransactionType] = [],
        id: String = UUID().uuidString
    ) {
        self.id = id
        self.name = name
        self.iconName = iconName
        self.peopleWaiting = peopleWaiting
        self.queuePrefix = queuePrefix
        self.location = location
        self.windowLabel = windowLabel
        self.currentlyServing = currentlyServing
        self.transactions = transactions
    }
}

// MARK: - Ticket (one document in Firestore `tickets`)

nonisolated enum TicketStatus: String {
    case active
    case completed
    case cancelled
    case noShow

    /// `nil` while the ticket is still in the queue (not history yet).
    var historyStatus: HistoryStatus? {
        switch self {
        case .active: return nil
        case .completed: return .completed
        case .cancelled: return .cancelled
        case .noShow: return .noShow
        }
    }
}

nonisolated struct Ticket: Identifiable, Hashable {
    let id: String
    let officeID: String
    let officeName: String
    let transactionName: String
    let studentName: String
    let number: Int
    let queueNumber: String
    let status: TicketStatus
    let createdAt: Date
}

// MARK: - Queue State

nonisolated enum QueueState: String {
    case waiting = "WAITING"
    case yourTurn = "YOUR TURN"
    case none = "NONE"
}

// MARK: - History

nonisolated enum HistoryStatus: String {
    case completed = "Completed"
    case cancelled = "Cancelled"
    case noShow = "No-show"
}

nonisolated struct HistoryEntry: Identifiable {
    var id: String = UUID().uuidString
    let queueNumber: String
    let office: String
    let transaction: String
    let date: String
    let status: HistoryStatus
}
