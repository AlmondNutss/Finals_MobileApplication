//
//  QueueService.swift
//  Midterms
//
//  The controller only talks to this protocol, so the backend can be swapped
//  (Firebase today, anything else later) without touching the Views.
//

import Foundation

nonisolated struct StudentProfile {
    let uid: String
    let name: String
    let studentID: String
    let email: String
    /// Set manually in Firestore (students/{uid}.isStaff = true).
    let isStaff: Bool
}

nonisolated struct AppConfig {
    let appSubtitle: String
    let averageMinutesPerPerson: Double
}

nonisolated enum QueueServiceError: LocalizedError {
    case notSignedIn
    case missingConfig
    case missingSeedFile

    var errorDescription: String? {
        switch self {
        case .notSignedIn: return "You are not signed in."
        case .missingConfig: return "The app configuration (config/app) is missing in Firestore."
        case .missingSeedFile: return "QueueSeed.json was not found in the app bundle."
        }
    }
}

/// Handle for a live listener. Call `remove()` (or let it deinit) to stop it.
nonisolated final class QueueListener {
    private var onRemove: (() -> Void)?

    init(_ onRemove: @escaping () -> Void) {
        self.onRemove = onRemove
    }

    func remove() {
        onRemove?()
        onRemove = nil
    }

    deinit {
        onRemove?()
    }
}

nonisolated protocol QueueService {
    // Authentication
    var currentUserID: String? { get }
    func signIn(email: String, password: String) async throws
    func register(email: String, password: String, name: String, studentID: String) async throws
    func signOut() throws
    func fetchProfile() async throws -> StudentProfile

    // Reference data
    func fetchConfig() async throws -> AppConfig
    /// Uploads QueueSeed.json to the database if it has never been set up.
    func seedIfNeeded() async throws

    // Live data
    func listenToOffices(_ onChange: @escaping @MainActor ([Office]) -> Void) -> QueueListener
    func listenToTickets(_ onChange: @escaping @MainActor ([Ticket]) -> Void) -> QueueListener

    // Staff
    func listenToOfficeTickets(officeID: String, _ onChange: @escaping @MainActor ([Ticket]) -> Void) -> QueueListener
    /// Finishes whoever is being served (`servedStatus`) and calls the next active ticket.
    func advanceQueue(office: Office, servedStatus: TicketStatus) async throws

    // Actions
    func joinQueue(office: Office, transaction: TransactionType, student: StudentProfile) async throws
    func updateTicket(id: String, status: TicketStatus) async throws
}
