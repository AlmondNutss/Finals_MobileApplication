//
//  FirebaseQueueService.swift
//  Midterms
//
//  Firestore layout
//    config/app                 appSubtitle, averageMinutesPerPerson
//    students/{uid}             name, studentID, email
//    offices/{officeId}         name, iconName, queuePrefix, location, windowLabel,
//                               currentlyServing, lastIssued, sortOrder,
//                               transactions: [{ name, description }]
//    tickets/{ticketId}         studentUID, studentName, studentID, officeID, officeName,
//                               transactionName, number, queueNumber,
//                               status (active | completed | cancelled | noShow), createdAt
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

nonisolated final class FirebaseQueueService: QueueService {

    init() {}

    // MARK: Firebase handles

    private func configureIfNeeded() {
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
    }

    private var db: Firestore {
        configureIfNeeded()
        return Firestore.firestore()
    }

    private var auth: Auth {
        configureIfNeeded()
        return Auth.auth()
    }

    // MARK: - Authentication

    var currentUserID: String? {
        auth.currentUser?.uid
    }

    func signIn(email: String, password: String) async throws {
        _ = try await auth.signIn(withEmail: email, password: password)
    }

    func register(email: String, password: String, name: String, studentID: String) async throws {
        let result = try await auth.createUser(withEmail: email, password: password)
        try await db.collection("students").document(result.user.uid).setData([
            "name": name,
            "studentID": studentID,
            "email": email
        ])
    }

    func signOut() throws {
        try auth.signOut()
    }

    func fetchProfile() async throws -> StudentProfile {
        guard let user = auth.currentUser else { throw QueueServiceError.notSignedIn }
        let snapshot = try await db.collection("students").document(user.uid).getDocument()
        let data = snapshot.data() ?? [:]
        return StudentProfile(
            uid: user.uid,
            name: data["name"] as? String ?? user.displayName ?? "",
            studentID: data["studentID"] as? String ?? "",
            email: user.email ?? "",
            isStaff: data["isStaff"] as? Bool ?? false
        )
    }

    // MARK: - Reference data

    func fetchConfig() async throws -> AppConfig {
        let snapshot = try await db.collection("config").document("app").getDocument()
        guard let data = snapshot.data(),
              let minutes = (data["averageMinutesPerPerson"] as? NSNumber)?.doubleValue else {
            throw QueueServiceError.missingConfig
        }
        return AppConfig(
            appSubtitle: data["appSubtitle"] as? String ?? "",
            averageMinutesPerPerson: minutes
        )
    }

    func seedIfNeeded() async throws {
        let configRef = db.collection("config").document("app")
        let existing = try await configRef.getDocument()
        if existing.exists { return }

        guard let url = Bundle.main.url(forResource: "QueueSeed", withExtension: "json") else {
            throw QueueServiceError.missingSeedFile
        }
        let seed = try JSONDecoder().decode(SeedData.self, from: Data(contentsOf: url))

        let batch = db.batch()
        batch.setData([
            "appSubtitle": seed.appSubtitle,
            "averageMinutesPerPerson": seed.averageMinutesPerPerson
        ], forDocument: configRef)

        for (index, office) in seed.offices.enumerated() {
            let ref = db.collection("offices").document(Self.slug(office.name))
            let transactions: [[String: Any]] = office.transactions.map {
                ["name": $0.name, "description": $0.description]
            }
            batch.setData([
                "name": office.name,
                "iconName": office.iconName,
                "queuePrefix": office.queuePrefix,
                "location": office.location,
                "windowLabel": office.windowLabel,
                "currentlyServing": office.currentlyServing,
                "lastIssued": office.currentlyServing + office.peopleWaiting,
                "sortOrder": index,
                "transactions": transactions
            ], forDocument: ref)
        }
        try await batch.commit()
    }

    // MARK: - Live data

    func listenToOffices(_ onChange: @escaping @MainActor ([Office]) -> Void) -> QueueListener {
        let registration = db.collection("offices")
            .order(by: "sortOrder")
            .addSnapshotListener { snapshot, _ in
                guard let snapshot else { return }
                let offices = snapshot.documents.map { Self.office(from: $0) }
                Task { @MainActor in
                    onChange(offices)
                }
            }
        return QueueListener { registration.remove() }
    }

    func listenToTickets(_ onChange: @escaping @MainActor ([Ticket]) -> Void) -> QueueListener {
        guard let uid = currentUserID else { return QueueListener { } }
        let registration = db.collection("tickets")
            .whereField("studentUID", isEqualTo: uid)
            .addSnapshotListener { snapshot, _ in
                guard let snapshot else { return }
                let tickets = snapshot.documents.map { Self.ticket(from: $0) }
                Task { @MainActor in
                    onChange(tickets)
                }
            }
        return QueueListener { registration.remove() }
    }

    // MARK: - Actions

    /// Takes the next ticket number atomically, so two students can never get
    /// the same number.
    func joinQueue(office: Office, transaction: TransactionType, student: StudentProfile) async throws {
        let officeRef = db.collection("offices").document(office.id)
        let ticketRef = db.collection("tickets").document()

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            db.runTransaction({ fsTransaction, errorPointer in
                let snapshot: DocumentSnapshot
                do {
                    snapshot = try fsTransaction.getDocument(officeRef)
                } catch {
                    errorPointer?.pointee = error as NSError
                    return nil
                }

                let data = snapshot.data() ?? [:]
                let lastIssued = (data["lastIssued"] as? NSNumber)?.intValue ?? 0
                let prefix = data["queuePrefix"] as? String ?? ""
                let number = lastIssued + 1
                let queueNumber = "\(prefix)-" + String(format: "%03d", number)

                fsTransaction.updateData(["lastIssued": number], forDocument: officeRef)
                fsTransaction.setData([
                    "studentUID": student.uid,
                    "studentName": student.name,
                    "studentID": student.studentID,
                    "officeID": office.id,
                    "officeName": office.name,
                    "transactionName": transaction.name,
                    "number": number,
                    "queueNumber": queueNumber,
                    "status": TicketStatus.active.rawValue,
                    "createdAt": FieldValue.serverTimestamp()
                ], forDocument: ticketRef)
                return nil
            }, completion: { _, error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            })
        }
    }

    func updateTicket(id: String, status: TicketStatus) async throws {
        try await db.collection("tickets").document(id).updateData([
            "status": status.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ])
    }

    // MARK: - Staff

    func listenToOfficeTickets(officeID: String, _ onChange: @escaping @MainActor ([Ticket]) -> Void) -> QueueListener {
        let registration = db.collection("tickets")
            .whereField("officeID", isEqualTo: officeID)
            .whereField("status", isEqualTo: TicketStatus.active.rawValue)
            .addSnapshotListener { snapshot, _ in
                guard let snapshot else { return }
                let tickets = snapshot.documents
                    .map { Self.ticket(from: $0) }
                    .sorted { $0.number < $1.number }
                Task { @MainActor in
                    onChange(tickets)
                }
            }
        return QueueListener { registration.remove() }
    }

    func advanceQueue(office: Office, servedStatus: TicketStatus) async throws {
        let officeRef = db.collection("offices").document(office.id)
        let officeData = try await officeRef.getDocument().data() ?? [:]
        let serving = (officeData["currentlyServing"] as? NSNumber)?.intValue ?? 0
        let lastIssued = (officeData["lastIssued"] as? NSNumber)?.intValue ?? 0

        let active = try await db.collection("tickets")
            .whereField("officeID", isEqualTo: office.id)
            .whereField("status", isEqualTo: TicketStatus.active.rawValue)
            .getDocuments()

        let batch = db.batch()
        var waitingNumbers: [Int] = []

        for document in active.documents {
            let number = (document.data()["number"] as? NSNumber)?.intValue ?? 0
            if number <= serving {
                // Already called — this is the one being finished.
                batch.updateData([
                    "status": servedStatus.rawValue,
                    "updatedAt": FieldValue.serverTimestamp()
                ], forDocument: document.reference)
            } else {
                waitingNumbers.append(number)
            }
        }

        // Next active ticket; if nobody is waiting, skip past any cancelled numbers.
        let next = waitingNumbers.min() ?? lastIssued
        batch.updateData(["currentlyServing": max(next, serving)], forDocument: officeRef)
        try await batch.commit()
    }

    // MARK: - Parsing

    private static func office(from document: QueryDocumentSnapshot) -> Office {
        let data = document.data()
        let currentlyServing = (data["currentlyServing"] as? NSNumber)?.intValue ?? 0
        let lastIssued = (data["lastIssued"] as? NSNumber)?.intValue ?? 0
        let rawTransactions = data["transactions"] as? [[String: Any]] ?? []

        return Office(
            name: data["name"] as? String ?? "",
            iconName: data["iconName"] as? String ?? "building.2.fill",
            peopleWaiting: max(lastIssued - currentlyServing, 0),
            queuePrefix: data["queuePrefix"] as? String ?? "Q",
            location: data["location"] as? String ?? "",
            windowLabel: data["windowLabel"] as? String ?? "",
            currentlyServing: currentlyServing,
            transactions: rawTransactions.map {
                TransactionType(
                    name: $0["name"] as? String ?? "",
                    description: $0["description"] as? String ?? ""
                )
            },
            id: document.documentID
        )
    }

    private static func ticket(from document: QueryDocumentSnapshot) -> Ticket {
        // `.estimate` fills in the pending server timestamp of a just-created ticket.
        let data = document.data(with: .estimate)
        return Ticket(
            id: document.documentID,
            officeID: data["officeID"] as? String ?? "",
            officeName: data["officeName"] as? String ?? "",
            transactionName: data["transactionName"] as? String ?? "",
            studentName: data["studentName"] as? String ?? "",
            number: (data["number"] as? NSNumber)?.intValue ?? 0,
            queueNumber: data["queueNumber"] as? String ?? "",
            status: TicketStatus(rawValue: data["status"] as? String ?? "") ?? .cancelled,
            createdAt: (data["createdAt"] as? Timestamp)?.dateValue() ?? Date()
        )
    }

    private static func slug(_ name: String) -> String {
        name.lowercased().replacingOccurrences(of: " ", with: "-")
    }

    // MARK: - Seed file format (QueueSeed.json)

    private struct SeedData: Decodable {
        let appSubtitle: String
        let averageMinutesPerPerson: Double
        let offices: [SeedOffice]
    }

    private struct SeedOffice: Decodable {
        let name: String
        let iconName: String
        let queuePrefix: String
        let location: String
        let windowLabel: String
        let peopleWaiting: Int
        let currentlyServing: Int
        let transactions: [SeedTransaction]
    }

    private struct SeedTransaction: Decodable {
        let name: String
        let description: String
    }
}
