//
//  MidtermsApp.swift
//  Midterms
//
//  Created by Mac-LAB on 9/3/26.
//

import SwiftUI
import FirebaseCore

@main
struct MidtermsApp: App {
    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
